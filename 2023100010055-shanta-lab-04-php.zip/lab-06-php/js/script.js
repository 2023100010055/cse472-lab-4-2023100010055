// CSE472 Lab 06: PHP Foundations and Form Processing
// SEU Innovation Summit - Information and Registration Page

// ---------- Features carried forward from the previous labs ----------

// Number of seats still available for the Summit
let availableSeats = 12;

// Show the current registration status
function checkRegistration() {
    let message = document.getElementById("registrationStatus");
    message.textContent = "Registration is currently open.";
}

// Check whether seats are available and show the result
function checkSeats() {
    let message = document.getElementById("seatMessage");

    if (availableSeats > 0) {
        message.textContent = "Seats are available. Remaining seats: " + availableSeats;
    } else {
        message.textContent = "Sorry, no seats are available.";
    }
}

// Read the typed name and show a personal greeting
function showGreeting() {
    let name = document.getElementById("studentName").value;
    let output = document.getElementById("greetingMessage");
    output.textContent = "Welcome, " + name + "!";
}

// Show a check-in reminder for participants
function showReminder() {
    let reminder = document.getElementById("reminderMessage");
    reminder.textContent = "Reminder: Bring your SEU student ID card and arrive by 09:30 for check-in at the Convocation Lobby.";
}

// ---------- Lab 06: browser-side check before the form leaves for the server ----------

// This function runs from the onsubmit attribute of the form.
// Returning false stops the browser from sending the form.
// Returning true lets the browser send it to process.php.
// The same four fields are checked again by PHP, because the
// server must not trust a check that runs inside the browser.
function validateRegistration() {
    let studentId = document.getElementById("studentId").value.trim();
    let name = document.getElementById("studentName").value.trim();
    let email = document.getElementById("studentEmail").value.trim();
    let workshop = document.getElementById("workshop").value;
    let message = document.getElementById("formMessage");

    if (studentId === "") {
        message.textContent = "Please enter your student ID.";
        return false;
    }

    if (name === "") {
        message.textContent = "Please enter your full name.";
        return false;
    }

    if (email === "") {
        message.textContent = "Please enter your email address.";
        return false;
    }

    if (workshop === "") {
        message.textContent = "Please select a track.";
        return false;
    }

    // Everything the browser can check is present, so the form is
    // allowed to travel to the server for the real check.
    message.textContent = "Sending your registration to the server...";
    return true;
}

// ---------- Lab 04 features kept so the earlier work still runs ----------

// Group the typed values in one object, convert to JSON and save it
function showJsonPreview() {
    let registration = {
        studentId: document.getElementById("studentId").value,
        name: document.getElementById("studentName").value,
        email: document.getElementById("studentEmail").value,
        workshop: document.getElementById("workshop").value
    };

    let jsonData = JSON.stringify(registration);
    localStorage.setItem("registration", jsonData);
    document.getElementById("jsonOutput").textContent = jsonData;
}

// Load the saved registration and show it as a readable sentence
function showSavedRegistration() {
    let savedData = localStorage.getItem("registration");
    let output = document.getElementById("savedMessage");

    if (savedData === null) {
        output.textContent = "No saved registration was found.";
        return;
    }

    let registration = JSON.parse(savedData);

    output.textContent = registration.name + " (" + registration.studentId +
        ") registered for " + registration.workshop + ".";
}

// Remove the saved practice data so testing can start again
function clearRegistration() {
    localStorage.removeItem("registration");
    document.getElementById("jsonOutput").textContent = "No registration saved yet.";
    document.getElementById("savedMessage").textContent = "Saved registration cleared.";
}

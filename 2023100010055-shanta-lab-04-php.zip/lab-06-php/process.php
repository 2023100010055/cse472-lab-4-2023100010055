<?php
/* =========================================================
   CSE472 Lab 06 - process.php
   SEU Innovation Summit - server-side form processing.
   This file receives the registration form, checks the
   submitted values on the server and returns a result page.
   ========================================================= */

/* A small function that cleans one submitted value before it
   is used or printed on the page. */
function clean_input($value) {
    $value = trim($value);                 // removes spaces at the beginning and end
    $value = htmlspecialchars($value);     // helps display user text more safely
    return $value;
}

/* Read every submitted value.
   ?? "" is used so a missing field does not cause an error. */
$studentId   = clean_input($_POST["studentId"]   ?? "");
$studentName = clean_input($_POST["studentName"] ?? "");
$email       = clean_input($_POST["email"]       ?? "");
$phone       = clean_input($_POST["phone"]       ?? "");
$workshop    = clean_input($_POST["workshop"]    ?? "");
$message     = clean_input($_POST["message"]     ?? "");

/* The add-ons are checkboxes that share one name ending in [],
   so PHP receives them as an array instead of a single value. */
$addons = $_POST["addons"] ?? array();
$cleanAddons = array();
foreach ($addons as $addon) {
    $cleanAddons[] = clean_input($addon);
}

/* ---------- Server-side validation ---------- */
$hasError     = false;
$errorMessage = "";

if ($studentId == "") {
    $hasError = true;
    $errorMessage = "Student ID is required.";
} elseif ($studentName == "") {
    $hasError = true;
    $errorMessage = "Full name is required.";
} elseif ($email == "") {
    $hasError = true;
    $errorMessage = "Email address is required.";
} elseif ($workshop == "") {
    $hasError = true;
    $errorMessage = "Please select a track.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Result — SEU Innovation Summit</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- The same header as the form page, so the design stays consistent -->
    <header class="site-header">
        <div class="brand">
            <img class="brand-logo" src="images/seu-logo.png" alt="Southeast University logo">
            <span class="brand-icon">🚀</span>
            <h1>SEU Innovation Summit</h1>
        </div>
        <nav class="primary-nav">
            <ul>
                <li><a href="index.html#overview">Overview</a></li>
                <li><a href="index.html#agenda">Agenda</a></li>
                <li><a href="index.html#signup">Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="panel">

            <?php if ($hasError) { ?>

                <h2>Registration was not completed</h2>
                <p class="message-box error-box"><?php echo $errorMessage; ?></p>
                <p>
                    Nothing was recorded. Please go back, complete the missing field and
                    submit the form again.
                </p>
                <p><a class="back-link" href="index.html#signup">Go back to the form</a></p>

            <?php } else { ?>

                <h2>Registration received</h2>
                <p class="message-box success-box">
                    Thank you, <?php echo $studentName; ?>. Your place in the
                    <?php echo $workshop; ?> track has been recorded for this session.
                </p>

                <p>
                    The values below were sent by the browser with the POST method and
                    processed on the server by PHP.
                </p>

                <table class="result-table">
                    <caption>Submitted Registration Details</caption>
                    <tbody>
                        <tr>
                            <th>Student ID</th>
                            <td><?php echo $studentId; ?></td>
                        </tr>
                        <tr>
                            <th>Full Name</th>
                            <td><?php echo $studentName; ?></td>
                        </tr>
                        <tr>
                            <th>Email Address</th>
                            <td><?php echo $email; ?></td>
                        </tr>
                        <tr>
                            <th>Phone Number</th>
                            <td><?php echo ($phone == "") ? "Not provided" : $phone; ?></td>
                        </tr>
                        <tr>
                            <th>Chosen Track</th>
                            <td><?php echo $workshop; ?></td>
                        </tr>
                        <tr>
                            <th>Optional Add-ons</th>
                            <td>
                                <?php
                                if (count($cleanAddons) == 0) {
                                    echo "None selected";
                                } else {
                                    echo implode(", ", $cleanAddons);
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>What You Want to Learn</th>
                            <td><?php echo ($message == "") ? "Not provided" : $message; ?></td>
                        </tr>
                    </tbody>
                </table>

                <h3>What Happens Next</h3>
                <p>
                    A confirmation message with the check-in slot is sent to the email address
                    above. In this laboratory the details are only displayed, not stored. The
                    registration will be saved into a MySQL database in Lab 04.
                </p>

                <p><a class="back-link" href="index.html#signup">Submit another response</a></p>

            <?php } ?>

        </section>
    </main>

    <footer class="site-footer">
        <p>Organised by the Office of Research and Innovation, Southeast University.</p>
        <p><a href="https://www.seu.edu.bd" target="_blank" rel="noopener noreferrer">www.seu.edu.bd</a></p>
    </footer>

</body>
</html>
